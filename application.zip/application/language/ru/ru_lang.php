<?php

$lang["dil"] = "Ru";
$lang["ana_sehife"] = "Главная";
$lang["haqqimizda"] = "Около";
$lang["qalareya"] = "Галерея";
$lang["elaqe"] = "Контакт";
$lang["portfolio"] = "Портфолио";
$lang["sertifikatlar"] = "Сертификаты";
$lang["servisler"] = "Сервисы";
$lang["linkler"] = "Полезные ссылки";
$lang["huquqlar"] = "© 2019 Lucky Travel. Все права защищены.";
$lang["mobilizasiya"] = "Мобилизация судна";
$lang["quru_tersane"] = "Услуги по размещению в сухой док";
$lang["temir"] = "Ремонт и техобслуживание";



$lang["bizkimik"] = "Кто Мы?";
$lang["etrafli"] = "Подробный";
$lang["emekdaslarimiz"] = "Персонал";


$lang["turlar"] = "Туры";


//===========menim hissem (cavid)
$lang["popular_tours"] = "Məhşur Turlar";
$lang["need_help"] = "Köməyə Ehtiyacınız var?";
$lang["need_help_text"] = "Burda statik text olacaq";
$lang["our_tours"] = "Turlarımız";
$lang["tour"] = "Tur";

//ola biler deye her ehtimal yaziram
$lang["price"] = "Qiymət";
$lang["asc"] = "Artan";
$lang["desc"] = "Azalan";
$lang["popularity"] = "Populyarlıq";
$lang["view"] = "Görünüş";
$lang["search"] = "Axtarış";
$lang["write_tour_name"] = "Turun adını daxil edin";
$lang["write_tour_date"] = "Tarixi Seçin";
$lang["go_search"] = "Axtar";
$lang["price_range"] = "Qiymət aralığı";
//ola biler deye her ehtimal yaziram

//===========menim hissem (cavid)






