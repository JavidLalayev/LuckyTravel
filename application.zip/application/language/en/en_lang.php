<?php

$lang["dil"] = "En";
$lang["ana_sehife"] = "Home Page";
$lang["haqqimizda"] = "About";
$lang["qalareya"] = "Gallery";
$lang["elaqe"] = "Contact";
$lang["portfolio"] = "Portfolio";
$lang["sertifikatlar"] = "Sertificates";
$lang["servisler"] = "Services";
$lang["linkler"] = "Useful Links";
$lang["huquqlar"] = "© Copyrights 2019 Lucky Travel. All rights reserved.";
$lang["mobilizasiya"] = "Vessel mobilization";
$lang["quru_tersane"] = "Dry dock services";
$lang["temir"] = "Repair and maintenance";



$lang["bizkimik"] = "Who Are We?";
$lang["etrafli"] = "Read More";
$lang["emekdaslarimiz"] = "Partners";

$lang["turlar"] = "Tours";


//===========menim hissem (cavid)
$lang["popular_tours"] = "Məhşur Turlar";
$lang["need_help"] = "Köməyə Ehtiyacınız var?";
$lang["need_help_text"] = "Burda statik text olacaq";
$lang["our_tours"] = "Turlarımız";
$lang["tour"] = "Tur";

//ola biler deye her ehtimal yaziram
$lang["price"] = "Qiymət";
$lang["asc"] = "Artan";
$lang["desc"] = "Azalan";
$lang["popularity"] = "Populyarlıq";
$lang["view"] = "Görünüş";
$lang["search"] = "Axtarış";
$lang["write_tour_name"] = "Turun adını daxil edin";
$lang["write_tour_date"] = "Tarixi Seçin";
$lang["go_search"] = "Axtar";
$lang["price_range"] = "Qiymət aralığı";
//ola biler deye her ehtimal yaziram

//===========menim hissem (cavid)







