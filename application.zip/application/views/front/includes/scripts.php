


<script src="<?php echo base_url("public/front/") ?>js/jquery-2.1.4.min.js"></script>
<script src="<?php echo base_url("public/front/") ?>js/bootstrap.min.js"></script>
<script src="<?php echo base_url("public/front/") ?>js/jquery-ui.min.js"></script>
<script src="<?php echo base_url("public/front/") ?>js/idangerous.swiper.min.js"></script>
<script src="<?php echo base_url("public/front/") ?>js/jquery.viewportchecker.min.js"></script>
<script src="<?php echo base_url("public/front/") ?>js/isotope.pkgd.min.js"></script>
<script src="<?php echo base_url("public/front/") ?>js/jquery.mousewheel.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?sensor=false&amp;language=en"></script>
<!--<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&callback=initMap" async defer></script>-->
<script src="<?php echo base_url("public/front/") ?>js/map.js"></script>
<script src="<?php echo base_url("public/front/") ?>js/all.js"></script>
<script src="<?php echo base_url("public/front/") ?>js/custom.js"></script>




</body>

</html>